package com.cb.covid;

import org.junit.jupiter.api.Test;

/*class Covid19InfectedCasesApplicationTests {
	
	   
	@Test
	void contextLoads() {
		
	}*/
public class Covid19InfectedCasesApplicationTests {
	   @Test
	   public void main() {
		   Covid19InfectedCasesApplication.main(new String[] {});
	   }
	}
